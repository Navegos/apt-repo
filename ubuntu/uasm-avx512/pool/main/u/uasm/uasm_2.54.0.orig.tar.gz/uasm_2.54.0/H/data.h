#pragma once

#ifndef DATA_H
#define DATA_H

#include "basedefs.h"

UASM_PACK_PUSH_STACK

extern ret_code UASM_ABI   data_dir(int, struct asm_tok[], struct asym*);

UASM_PACK_POP

#endif
