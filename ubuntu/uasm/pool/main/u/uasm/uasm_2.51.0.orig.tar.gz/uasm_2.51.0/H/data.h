#pragma once

#ifndef DATA_H
#define DATA_H

#include "basedefs.h"

uasm_PACK_PUSH_STACK

extern ret_code   data_dir(int, struct asm_tok[], struct asym*);

uasm_PACK_POP

#endif
