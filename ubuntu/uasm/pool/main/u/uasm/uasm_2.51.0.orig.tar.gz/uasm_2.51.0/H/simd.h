#pragma once

#ifndef _H_SIMD
#define _H_SIMD

#include "basedefs.h"

uasm_PACK_PUSH_STACK

extern void AddSimdTypes();

uasm_PACK_POP

#endif
