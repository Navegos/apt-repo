#pragma once

#ifndef _MACROLIB_H_
#define _MACROLIB_H_

#include "basedefs.h"

uasm_PACK_PUSH_STACK

extern void Adddefs(void);
extern void CreateMacroLibCases(void);

uasm_PACK_POP

#endif
