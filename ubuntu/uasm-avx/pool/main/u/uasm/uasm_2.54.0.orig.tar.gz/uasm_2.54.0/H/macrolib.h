#pragma once

#ifndef _MACROLIB_H_
#define _MACROLIB_H_

#include "basedefs.h"

UASM_PACK_PUSH_STACK

extern void UASM_ABI Adddefs(void);
extern void UASM_ABI CreateMacroLibCases(void);

UASM_PACK_POP

#endif
