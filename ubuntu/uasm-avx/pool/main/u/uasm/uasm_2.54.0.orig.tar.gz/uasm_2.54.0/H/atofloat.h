#pragma once

#ifndef ATOFLOAT_H
#define ATOFLOAT_H

#include "basedefs.h"

UASM_PACK_PUSH_STACK

extern void UASM_ABI atofloat(void*, const char*, unsigned, bool, uint_8);

UASM_PACK_POP

#endif
