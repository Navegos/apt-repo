#pragma once

#ifndef _H_SIMD
#define _H_SIMD

#ifndef uasm_BASEDEFS_H
#include "basedefs.h"
#endif

UASM_PACK_PUSH_STACK

extern void UASM_ABI AddSimdTypes();

UASM_PACK_POP

#endif
