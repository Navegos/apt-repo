#ifndef REPREPRO_ARCHALLFLOOD_H
#define REPREPRO_ARCHALLFLOOD_H

retvalue flood(struct distribution *, /*@null@*/const struct atomlist * /*components*/, /*@NULL@*/const struct atomlist * /*architectures*/, /*@NULL@*/const struct atomlist * /*packagetypes*/, architecture_t, trackingdb);

#endif
