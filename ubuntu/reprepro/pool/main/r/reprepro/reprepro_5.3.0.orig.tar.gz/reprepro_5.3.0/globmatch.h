#ifndef REPREPRO_GLOBMATCH_H
#define REPREPRO_GLOBMATCH_H

bool globmatch(const char * /*string*/, const char */*pattern*/);

#endif

