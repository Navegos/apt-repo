#ifndef REPREPRO_PRINTLISTFORMAT
#define REPREPRO_PRINTLISTFORMAT

struct package;
retvalue listformat_print(const char *, struct package *);

#endif
