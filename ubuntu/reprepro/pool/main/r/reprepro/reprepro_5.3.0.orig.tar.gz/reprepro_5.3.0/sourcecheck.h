#ifndef REPREPRO_SOURCECHECK_H
#define REPREPRO_SOURCECHECK_H

retvalue unusedsources(struct distribution *);
retvalue sourcemissing(struct distribution *);
retvalue reportcruft(struct distribution *);

#endif
