#ifndef REPREPRO_SIZES_H
#define REPREPRO_SIZES_H

retvalue sizes_distributions(struct distribution * /*all*/, bool /* specific */);

#endif
